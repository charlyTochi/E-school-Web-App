@extends('layouts.app', ['activePage' => 'studentView', 'titlePage' => __('Student View')])

@section('content')
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">

        </div>
      </div>
    </div>
  </div>
@endsection
