<footer class="footer">
  <div class="container-fluid">
    <!-- <nav class="float-left">
      <ul>
        <li>
          <a href="https://www.creative-tim.com">
              {{ __('Creative Tim') }}
          </a>
        </li>
        <li>
          <a href="https://creative-tim.com/presentation">
              {{ __('About Us') }}
          </a>
        </li>
        <li>
          <a href="http://blog.creative-tim.com">
              {{ __('Blog') }}
          </a>
        </li>
        <li>
          <a href="https://www.creative-tim.com/license">
              {{ __('Licenses') }}
          </a>
        </li>
      </ul>
    </nav> -->
    <div class="copyright text-center text-white">
      &copy;
      <script>
        document.write(new Date().getFullYear())
      </script>, made with <i class="material-icons">favorite</i>
      <a href="https://www.e-school.com" target="_blank">Powered by Efull Technology Nig. Ltd</a>  for the best solution in tech.
    </div>
  </div>
</footer>
