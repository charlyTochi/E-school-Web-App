
    <html lang="en-US">
    	<head>
    		<meta charset="utf-8">
    	</head>
    	<body>
    		<h2>Dear, {{$data['parent_name']}}</h2>
    		<p>{{$data['message']}}</p>
    	</body>
    </html>
